# Agile Podcast Operations Tracker

A personal portfolio project (January to February 2025). I set up a Scrum plan for a podcast production workflow and tracked it in Jira, using YINT TALKS episode topics as the example workflow.

This was not run with a live production team, so the numbers below describe the plan and the dashboard, not measured business results.

## What I did

- Split the work for 6 episodes into 36 tasks across 3 two-week sprints (102 story points, about 34 per sprint).
- Grouped tasks by type: pre-production, guest research, video editing, thumbnail, YouTube upload and analytics.
- Built a Power BI sprint dashboard with task distribution, story points by episode, sprint velocity, and CTR and YouTube views by episode.

## Tools

Jira, ClickUp, Power BI, Agile Scrum

## Files

- `images/agile-sprint-dashboard.png`: the Power BI sprint dashboard
