# Employee Analytics Dashboard

An interactive Excel dashboard on a small sample HR dataset (10 employees, 3 locations).

## What it shows

- Employee count by department and by location.
- Monthly hiring trend for January to July 2023.
- Total, average, lowest and highest salary.
- Slicers for department and location and a timeline for join date.

## Tools

Excel (pivot tables, slicers, timeline, KPI cards)

## Files

- `images/employee-analytics-dashboard.jpg`: the dashboard
